#define MEMORYCORE_EXPORTS

#include "MemoryCore.h"

#include <windows.h>
#include <psapi.h>
#include <tlhelp32.h>
#include <iphlpapi.h>
#include <string.h>

#pragma comment(lib, "psapi.lib")
#pragma comment(lib, "iphlpapi.lib")

/* --- Memory Cleaning --- */

MEMCORE_API int CleanAllWorkingSets()
{
    int cleaned = 0;
    HANDLE hSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (hSnap == INVALID_HANDLE_VALUE) return 0;

    PROCESSENTRY32W pe;
    memset(&pe, 0, sizeof(pe));
    pe.dwSize = sizeof(pe);

    if (Process32FirstW(hSnap, &pe)) {
        do {
            if (pe.th32ProcessID == 0) continue;
            HANDLE hProc = OpenProcess(
                PROCESS_QUERY_INFORMATION | PROCESS_SET_QUOTA,
                FALSE, pe.th32ProcessID);
            if (hProc) {
                if (EmptyWorkingSet(hProc))
                    cleaned++;
                CloseHandle(hProc);
            }
        } while (Process32NextW(hSnap, &pe));
    }
    CloseHandle(hSnap);
    return cleaned;
}

MEMCORE_API int CleanProcessWorkingSet(uint32_t pid)
{
    HANDLE hProc = OpenProcess(
        PROCESS_QUERY_INFORMATION | PROCESS_SET_QUOTA,
        FALSE, pid);
    if (!hProc) return 0;
    int ok = EmptyWorkingSet(hProc) ? 1 : 0;
    CloseHandle(hProc);
    return ok;
}

/* --- Process List --- */

MEMCORE_API int GetProcessList(ProcessInfoNative* buffer, int bufferCount)
{
    if (!buffer || bufferCount <= 0) return 0;

    HANDLE hSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (hSnap == INVALID_HANDLE_VALUE) return 0;

    PROCESSENTRY32W pe;
    memset(&pe, 0, sizeof(pe));
    pe.dwSize = sizeof(pe);
    int count = 0;

    if (Process32FirstW(hSnap, &pe)) {
        do {
            if (count >= bufferCount) break;
            if (pe.th32ProcessID == 0) continue;

            ProcessInfoNative* p = &buffer[count];
            memset(p, 0, sizeof(ProcessInfoNative));
            p->pid = pe.th32ProcessID;
            wcsncpy_s(p->name, 260, pe.szExeFile, _TRUNCATE);

            HANDLE hProc = OpenProcess(
                PROCESS_QUERY_INFORMATION | PROCESS_VM_READ,
                FALSE, pe.th32ProcessID);
            if (hProc) {
                PROCESS_MEMORY_COUNTERS_EX pmc;
                memset(&pmc, 0, sizeof(pmc));
                pmc.cb = sizeof(pmc);
                if (GetProcessMemoryInfo(hProc,
                    (PROCESS_MEMORY_COUNTERS*)&pmc, sizeof(pmc)))
                {
                    p->workingSetSize = pmc.WorkingSetSize;
                    p->privateBytes = pmc.PrivateUsage;
                }

                WCHAR path[520];
                memset(path, 0, sizeof(path));
                DWORD pathLen = 520;
                if (QueryFullProcessImageNameW(hProc, 0, path, &pathLen)) {
                    wcsncpy_s(p->filePath, 520, path, _TRUNCATE);
                }

                CloseHandle(hProc);
            }

            count++;
        } while (Process32NextW(hSnap, &pe));
    }
    CloseHandle(hSnap);
    return count;
}

/* --- Kill Process --- */

MEMCORE_API int KillProcess(uint32_t pid)
{
    HANDLE hProc = OpenProcess(PROCESS_TERMINATE, FALSE, pid);
    if (!hProc) return 0;
    int ok = TerminateProcess(hProc, 1) ? 1 : 0;
    CloseHandle(hProc);
    return ok;
}

/* --- System Memory Info --- */

MEMCORE_API int GetSystemMemoryInfo(SystemMemoryInfo* info)
{
    if (!info) return 0;
    MEMORYSTATUSEX ms;
    memset(&ms, 0, sizeof(ms));
    ms.dwLength = sizeof(ms);
    if (!GlobalMemoryStatusEx(&ms)) return 0;

    info->totalPhysical = ms.ullTotalPhys;
    info->availablePhysical = ms.ullAvailPhys;
    info->memoryLoadPercent = ms.dwMemoryLoad;
    return 1;
}

/* --- Network Snapshot (using GetIfTable / MIB_IFTABLE) --- */

MEMCORE_API int GetNetworkSnapshot(NetworkSnapshot* snapshot)
{
    if (!snapshot) return 0;

    DWORD dwSize = 0;
    GetIfTable(NULL, &dwSize, FALSE);
    if (dwSize == 0) return 0;

    MIB_IFTABLE* pTable = (MIB_IFTABLE*)malloc(dwSize);
    if (!pTable) return 0;

    if (GetIfTable(pTable, &dwSize, FALSE) != NO_ERROR) {
        free(pTable);
        return 0;
    }

    uint64_t totalSent = 0, totalRecv = 0;
    for (DWORD i = 0; i < pTable->dwNumEntries; i++) {
        MIB_IFROW* row = &pTable->table[i];
        if (row->dwOperStatus == MIB_IF_OPER_STATUS_OPERATIONAL &&
            row->dwType != MIB_IF_TYPE_LOOPBACK)
        {
            totalSent += row->dwOutOctets;
            totalRecv += row->dwInOctets;
        }
    }
    free(pTable);

    snapshot->bytesSent = totalSent;
    snapshot->bytesRecv = totalRecv;
    return 1;
}
