#pragma once

#ifdef MEMORYCORE_EXPORTS
#define MEMCORE_API __declspec(dllexport)
#else
#define MEMCORE_API __declspec(dllimport)
#endif

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Memory cleaning */
MEMCORE_API int CleanAllWorkingSets(void);
MEMCORE_API int CleanProcessWorkingSet(uint32_t pid);

/* Process info */
#pragma pack(push, 1)
typedef struct {
    uint32_t pid;
    wchar_t  name[260];
    wchar_t  filePath[520];
    uint64_t workingSetSize;
    uint64_t privateBytes;
    double   cpuPercent;
} ProcessInfoNative;
#pragma pack(pop)

MEMCORE_API int GetProcessList(ProcessInfoNative* buffer, int bufferCount);
MEMCORE_API int KillProcess(uint32_t pid);

/* System memory info */
#pragma pack(push, 1)
typedef struct {
    uint64_t totalPhysical;
    uint64_t availablePhysical;
    uint32_t memoryLoadPercent;
} SystemMemoryInfo;
#pragma pack(pop)

MEMCORE_API int GetSystemMemoryInfo(SystemMemoryInfo* info);

/* Network speed */
#pragma pack(push, 1)
typedef struct {
    uint64_t bytesSent;
    uint64_t bytesRecv;
} NetworkSnapshot;
#pragma pack(pop)

MEMCORE_API int GetNetworkSnapshot(NetworkSnapshot* snapshot);

#ifdef __cplusplus
}
#endif
