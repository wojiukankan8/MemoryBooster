using System;

namespace MemoryBooster.Services;

public class NetworkMonitor
{
    private NetworkSnapshot _lastSnapshot;
    private DateTime _lastTime;
    private bool _initialized;

    public double UploadSpeed { get; private set; }   // bytes/s
    public double DownloadSpeed { get; private set; }  // bytes/s
    public ulong TotalSent { get; private set; }
    public ulong TotalRecv { get; private set; }

    public void Update()
    {
        var snapshot = new NetworkSnapshot();
        if (NativeInterop.GetNetworkSnapshot(ref snapshot) == 0) return;

        var now = DateTime.UtcNow;
        if (_initialized)
        {
            double elapsed = (now - _lastTime).TotalSeconds;
            if (elapsed > 0.1)
            {
                UploadSpeed = (snapshot.BytesSent - _lastSnapshot.BytesSent) / elapsed;
                DownloadSpeed = (snapshot.BytesRecv - _lastSnapshot.BytesRecv) / elapsed;
                if (UploadSpeed < 0) UploadSpeed = 0;
                if (DownloadSpeed < 0) DownloadSpeed = 0;
            }
        }
        _lastSnapshot = snapshot;
        _lastTime = now;
        _initialized = true;
        TotalSent = snapshot.BytesSent;
        TotalRecv = snapshot.BytesRecv;
    }

    public static string FormatSpeed(double bytesPerSec)
    {
        if (bytesPerSec < 1024) return $"{bytesPerSec:F0} B/s";
        if (bytesPerSec < 1024 * 1024) return $"{bytesPerSec / 1024:F1} KB/s";
        return $"{bytesPerSec / (1024 * 1024):F2} MB/s";
    }
}
