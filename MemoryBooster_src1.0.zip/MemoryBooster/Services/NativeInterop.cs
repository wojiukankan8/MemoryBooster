using System.Runtime.InteropServices;

namespace MemoryBooster.Services;

[StructLayout(LayoutKind.Sequential, Pack = 1, CharSet = CharSet.Unicode)]
public struct ProcessInfoNative
{
    public uint Pid;
    [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)]
    public string Name;
    [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 520)]
    public string FilePath;
    public ulong WorkingSetSize;
    public ulong PrivateBytes;
    public double CpuPercent;
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct SystemMemoryInfo
{
    public ulong TotalPhysical;
    public ulong AvailablePhysical;
    public uint MemoryLoadPercent;
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct NetworkSnapshot
{
    public ulong BytesSent;
    public ulong BytesRecv;
}

public static class NativeInterop
{
    private const string DllName = "MemoryCore.dll";

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl)]
    public static extern int CleanAllWorkingSets();

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl)]
    public static extern int CleanProcessWorkingSet(uint pid);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl)]
    public static extern int GetProcessList(
        [Out] ProcessInfoNative[] buffer, int bufferCount);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl)]
    public static extern int KillProcess(uint pid);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl)]
    public static extern int GetSystemMemoryInfo(ref SystemMemoryInfo info);

    [DllImport(DllName, CallingConvention = CallingConvention.Cdecl)]
    public static extern int GetNetworkSnapshot(ref NetworkSnapshot snapshot);
}
