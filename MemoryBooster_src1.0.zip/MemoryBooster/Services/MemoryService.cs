using System;
using System.Collections.Generic;
using System.Threading;
using MemoryBooster.Models;

namespace MemoryBooster.Services;

public class MemoryService
{
    public (int cleaned, ulong freedBytes) CleanMemory()
    {
        var before = GetMemoryInfo();
        int cleaned = NativeInterop.CleanAllWorkingSets();
        Thread.Sleep(200);
        var after = GetMemoryInfo();

        ulong freed = 0;
        if (before.AvailablePhysical < after.AvailablePhysical)
            freed = after.AvailablePhysical - before.AvailablePhysical;

        return (cleaned, freed);
    }

    public SystemMemoryInfo GetMemoryInfo()
    {
        var info = new SystemMemoryInfo();
        NativeInterop.GetSystemMemoryInfo(ref info);
        return info;
    }

    public uint GetMemoryLoadPercent()
    {
        var info = GetMemoryInfo();
        return info.MemoryLoadPercent;
    }

    public List<ProcessInfo> GetProcessList()
    {
        var buffer = new ProcessInfoNative[1024];
        int count = NativeInterop.GetProcessList(buffer, buffer.Length);
        var list = new List<ProcessInfo>(count);
        for (int i = 0; i < count; i++)
        {
            list.Add(new ProcessInfo
            {
                Pid = buffer[i].Pid,
                Name = buffer[i].Name ?? "",
                FilePath = buffer[i].FilePath ?? "",
                WorkingSet = buffer[i].WorkingSetSize,
                PrivateBytes = buffer[i].PrivateBytes
            });
        }
        list.Sort((a, b) => b.WorkingSet.CompareTo(a.WorkingSet));
        return list;
    }

    public bool KillProcess(uint pid) => NativeInterop.KillProcess(pid) != 0;

    public bool CleanProcess(uint pid) => NativeInterop.CleanProcessWorkingSet(pid) != 0;
}
