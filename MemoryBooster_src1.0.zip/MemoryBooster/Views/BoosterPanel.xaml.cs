using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Threading;
using MemoryBooster.Models;
using MemoryBooster.Services;

namespace MemoryBooster.Views;

public partial class BoosterPanel : Window
{
    private readonly MemoryService _memService;
    private readonly NetworkMonitor _netMonitor;
    private readonly AppSettings _settings;
    private readonly DispatcherTimer _refreshTimer;

    private ProcessInfo _selectedProcess;
    private bool _loaded;

    public event Action SettingsChanged;

    public BoosterPanel(MemoryService memService, NetworkMonitor netMonitor, AppSettings settings)
    {
        _memService = memService;
        _netMonitor = netMonitor;
        _settings = settings;
        InitializeComponent();
        _loaded = true;

        LoadSettings();
        RefreshProcessList();
        UpdateMemoryBar();

        _refreshTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(2) };
        _refreshTimer.Tick += (s, ev) => { try { OnTimerTick(); } catch { } };
        _refreshTimer.Start();

        Closed += (s, ev) => _refreshTimer.Stop();
    }

    private void OnTimerTick()
    {
        UpdateMemoryBar();
        if (NetworkPanel.Visibility == Visibility.Visible)
            UpdateNetworkDisplay();
    }

    // ── Process Tab ──
    private void RefreshProcessList()
    {
        var list = _memService.GetProcessList();
        ProcessGrid.ItemsSource = list;

        // Update total memory display in list header
        ulong totalWs = 0;
        foreach (var p in list) totalWs += p.WorkingSet;
        if (TxtTotalMem != null)
            TxtTotalMem.Text = ProcessInfo.FormatBytes(totalWs);
    }

    private void UpdateMemoryBar()
    {
        var info = _memService.GetMemoryInfo();
        uint pct = info.MemoryLoadPercent;
        double totalGB = info.TotalPhysical / (1024.0 * 1024 * 1024);
        double usedGB = (info.TotalPhysical - info.AvailablePhysical) / (1024.0 * 1024 * 1024);

        // Header big percentage
        if (TxtMemPct != null) TxtMemPct.Text = pct.ToString();
        if (TxtMemStatus != null)
        {
            if (pct < 50) TxtMemStatus.Text = "\u7535\u8111\u5145\u6EE1\u6D3B\u529B";
            else if (pct < 80) TxtMemStatus.Text = "\u5185\u5B58\u5360\u7528\u8F83\u9AD8";
            else TxtMemStatus.Text = "\u5185\u5B58\u5360\u7528\u8FC7\u9AD8!";
        }
        TxtMemInfo.Text = $"\u5185\u5B58: {pct}% \u5DF2\u7528";
        TxtMemDetail.Text = $"({usedGB:F1} / {totalGB:F1} GB)";
    }

    private void OnProcessSelected(object sender, SelectedCellsChangedEventArgs e)
    {
        _selectedProcess = ProcessGrid.SelectedItem as ProcessInfo;
        bool hasSel = _selectedProcess != null;
        BtnCleanProc.IsEnabled = hasSel;
        BtnKillProc.IsEnabled = hasSel;
    }

    private void OnCleanProcess(object sender, RoutedEventArgs e)
    {
        if (_selectedProcess == null) return;
        _memService.CleanProcess(_selectedProcess.Pid);
        RefreshProcessList();
    }

    private void OnKillProcess(object sender, RoutedEventArgs e)
    {
        if (_selectedProcess == null) return;
        var result = MessageBox.Show(
            $"\u786E\u5B9A\u8981\u7ED3\u675F\u8FDB\u7A0B \"{_selectedProcess.Name}\" (PID: {_selectedProcess.Pid}) \u5417?\n\u5F3A\u5236\u7ED3\u675F\u53EF\u80FD\u5BFC\u81F4\u6570\u636E\u4E22\u5931\u3002",
            "\u786E\u8BA4", MessageBoxButton.YesNo, MessageBoxImage.Warning);
        if (result == MessageBoxResult.Yes)
        {
            _memService.KillProcess(_selectedProcess.Pid);
            RefreshProcessList();
        }
    }

    private async void OnOneClickBoost(object sender, RoutedEventArgs e)
    {
        var btn = (Button)sender;
        btn.IsEnabled = false;
        btn.Content = "\u6E05\u7406\u4E2D...";

        var result = await Task.Run(() => _memService.CleanMemory());

        btn.Content = $"\u5DF2\u91CA\u653E {ProcessInfo.FormatBytes(result.freedBytes)}";
        RefreshProcessList();
        UpdateMemoryBar();

        await Task.Delay(2000);
        btn.Content = "\u4E00\u952E\u52A0\u901F";
        btn.IsEnabled = true;
    }

    // ── Network Tab ──
    private void UpdateNetworkDisplay()
    {
        _netMonitor.Update();
        TxtDlSpeed.Text = NetworkMonitor.FormatSpeed(_netMonitor.DownloadSpeed);
        TxtUlSpeed.Text = NetworkMonitor.FormatSpeed(_netMonitor.UploadSpeed);
        TxtTotalDl.Text = ProcessInfo.FormatBytes(_netMonitor.TotalRecv);
        TxtTotalUl.Text = ProcessInfo.FormatBytes(_netMonitor.TotalSent);
    }

    // ── Settings Tab ──
    private void LoadSettings()
    {
        ChkAutoStart.IsChecked = StartupManager.IsEnabled();
        ChkAutoClean.IsChecked = _settings.AutoClean;
        TxtInterval.Text = _settings.AutoCleanIntervalMinutes.ToString();
        SliderOpacity.Value = _settings.BallOpacity;

        switch (_settings.BallSkin)
        {
            case 1: SkinBlue.IsChecked = true; break;
            case 2: SkinPurple.IsChecked = true; break;
            default: SkinDefault.IsChecked = true; break;
        }
    }

    private void OnAutoStartChanged(object sender, RoutedEventArgs e)
    {
        if (!_loaded) return;
        bool enabled = ChkAutoStart.IsChecked == true;
        _settings.AutoStart = enabled;
        try { StartupManager.SetEnabled(enabled); } catch { }
        NotifySettingsChanged();
    }

    private void OnAutoCleanChanged(object sender, RoutedEventArgs e)
    {
        if (!_loaded) return;
        _settings.AutoClean = ChkAutoClean.IsChecked == true;
        NotifySettingsChanged();
    }

    private void OnIntervalChanged(object sender, TextChangedEventArgs e)
    {
        if (!_loaded) return;
        if (int.TryParse(TxtInterval.Text, out int val) && val > 0)
        {
            _settings.AutoCleanIntervalMinutes = val;
            NotifySettingsChanged();
        }
    }

    private void OnOpacityChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
        if (!_loaded) return;
        _settings.BallOpacity = SliderOpacity.Value;
        NotifySettingsChanged();
    }

    private void OnSkinChanged(object sender, RoutedEventArgs e)
    {
        if (!_loaded) return;
        if (SkinBlue.IsChecked == true) _settings.BallSkin = 1;
        else if (SkinPurple.IsChecked == true) _settings.BallSkin = 2;
        else _settings.BallSkin = 0;
        NotifySettingsChanged();
    }

    private void NotifySettingsChanged()
    {
        var h = SettingsChanged;
        if (h != null) h();
    }

    // ── Tab switch ──
    private void TabChanged(object sender, RoutedEventArgs e)
    {
        if (!_loaded) return;
        ProcessPanel.Visibility = TabProcess.IsChecked == true ? Visibility.Visible : Visibility.Collapsed;
        NetworkPanel.Visibility = TabNetwork.IsChecked == true ? Visibility.Visible : Visibility.Collapsed;
        SettingsPanel.Visibility = TabSettings.IsChecked == true ? Visibility.Visible : Visibility.Collapsed;

        if (TabProcess.IsChecked == true)
            RefreshProcessList();
        if (TabNetwork.IsChecked == true)
            UpdateNetworkDisplay();
    }

    // ── Title drag ──
    private void OnTitleDrag(object sender, MouseButtonEventArgs e)
    {
        if (e.LeftButton == MouseButtonState.Pressed)
            DragMove();
    }

    private void OnClose(object sender, RoutedEventArgs e)
    {
        Close();
    }

    private void OnExitApp(object sender, RoutedEventArgs e)
    {
        Application.Current.Shutdown();
    }
}
