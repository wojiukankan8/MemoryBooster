using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace MemoryBooster.Models;

public class ProcessInfo : INotifyPropertyChanged
{
    public uint Pid { get; set; }
    public string Name { get; set; } = "";
    public string FilePath { get; set; } = "";

    private ulong _workingSet;
    public ulong WorkingSet
    {
        get => _workingSet;
        set { _workingSet = value; OnPropertyChanged(); OnPropertyChanged(nameof(WorkingSetDisplay)); }
    }

    private ulong _privateBytes;
    public ulong PrivateBytes
    {
        get => _privateBytes;
        set { _privateBytes = value; OnPropertyChanged(); }
    }

    private bool _isSelected;
    public bool IsSelected
    {
        get => _isSelected;
        set { _isSelected = value; OnPropertyChanged(); }
    }

    public string WorkingSetDisplay => FormatBytes(WorkingSet);

    public static string FormatBytes(ulong bytes)
    {
        if (bytes < 1024) return $"{bytes} B";
        if (bytes < 1024 * 1024) return $"{bytes / 1024.0:F1} KB";
        if (bytes < 1024UL * 1024 * 1024) return $"{bytes / (1024.0 * 1024):F1} MB";
        return $"{bytes / (1024.0 * 1024 * 1024):F2} GB";
    }

    public event PropertyChangedEventHandler PropertyChanged;
    protected void OnPropertyChanged([CallerMemberName] string name = null)
    {
        var h = PropertyChanged;
        if (h != null) h(this, new PropertyChangedEventArgs(name));
    }
}
