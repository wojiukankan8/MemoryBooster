﻿using System;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Threading;
using MemoryBooster.Models;
using MemoryBooster.Services;
using MemoryBooster.Views;

namespace MemoryBooster;

public partial class MainWindow : Window
{
    private readonly MemoryService _memService = new MemoryService();
    private readonly NetworkMonitor _netMonitor = new NetworkMonitor();
    private readonly DispatcherTimer _updateTimer;
    private readonly DispatcherTimer _netTimer;
    private readonly DispatcherTimer _autoCleanTimer;

    private AppSettings _settings;
    private bool _isCleaning;
    private bool _isDragging;
    private Point _dragStart;
    private double _windowTop;
    private BoosterPanel _panel;
    private Storyboard _spinStoryboard;

    // Edge-hide state
    private readonly DispatcherTimer _hideTimer;
    private bool _isHidden;
    private double _screenRight;
    private const double PeekWidth = 14;

    public MainWindow()
    {
        InitializeComponent();
        _settings = AppSettings.Load();

        // Position
        _screenRight = SystemParameters.PrimaryScreenWidth;
        double posY = _settings.BallPositionY >= 0
            ? _settings.BallPositionY
            : (SystemParameters.PrimaryScreenHeight / 2 - Height / 2);
        Left = _screenRight - PeekWidth;
        Top = posY;
        _isHidden = true;

        Opacity = _settings.BallOpacity;

        // Memory update timer (2s)
        _updateTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(2) };
        _updateTimer.Tick += (s, e) => { try { UpdateMemoryDisplay(); } catch { } };
        _updateTimer.Start();

        // Network update timer (1s)
        _netTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1) };
        _netTimer.Tick += (s, e) => { try { UpdateNetworkDisplay(); } catch { } };
        _netTimer.Start();

        // Auto-clean timer
        _autoCleanTimer = new DispatcherTimer();
        _autoCleanTimer.Tick += async (s, e) => { try { await DoCleanAsync(); } catch { } };
        ApplyAutoCleanSettings();

        // Hide timer
        _hideTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(800) };
        _hideTimer.Tick += (s, e) => { _hideTimer.Stop(); SlideToEdge(); };

        // Events
        MouseEnter += (s, e) => { _hideTimer.Stop(); SlideIn(); };
        MouseLeave += (s, e) => { if (!_isDragging && _panel == null) _hideTimer.Start(); };
        MouseLeftButtonDown += OnBallMouseDown;
        MouseMove += OnBallMouseMove;
        MouseLeftButtonUp += OnBallMouseUp;
        MouseRightButtonUp += OnRightClick;

        // Initial display
        try { UpdateMemoryDisplay(); } catch { }
        try { _netMonitor.Update(); } catch { }

        // Spinner animation
        SetupSpinnerAnimation();
    }

    private void SetupSpinnerAnimation()
    {
        var anim = new DoubleAnimation(0, 360, TimeSpan.FromSeconds(1))
        {
            RepeatBehavior = RepeatBehavior.Forever
        };
        _spinStoryboard = new Storyboard();
        _spinStoryboard.Children.Add(anim);
        Storyboard.SetTarget(anim, SpinnerArc);
        Storyboard.SetTargetProperty(anim,
            new PropertyPath("(Path.RenderTransform).(RotateTransform.Angle)"));
    }

    // ── Memory Display ──
    private void UpdateMemoryDisplay()
    {
        if (_isCleaning) return;
        uint pct = _memService.GetMemoryLoadPercent();
        TxtPercent.Text = $"{pct}%";
        UpdateBallColor(pct);
    }

    private void UpdateBallColor(uint pct)
    {
        Color bright, dark;
        if (pct < 50)
        {
            byte r = (byte)(255 * pct / 50);
            bright = Color.FromRgb(r, 255, 80);
            dark = Color.FromRgb((byte)(r * 0.5), 180, 40);
        }
        else if (pct < 80)
        {
            byte g = (byte)(255 * (80 - pct) / 30);
            bright = Color.FromRgb(255, g, 50);
            dark = Color.FromRgb(200, (byte)(g * 0.6), 30);
        }
        else
        {
            bright = Color.FromRgb(255, 60, 60);
            dark = Color.FromRgb(180, 20, 20);
        }
        GradStop1.Color = bright;
        GradStop2.Color = dark;
    }

    // ── Network Display ──
    private void UpdateNetworkDisplay()
    {
        _netMonitor.Update();
        if (_isHidden) return;
        NetSpeedPanel.Visibility = Visibility.Visible;
        TxtUpSpeed.Text = $"\u2191 {NetworkMonitor.FormatSpeed(_netMonitor.UploadSpeed)}";
        TxtDownSpeed.Text = $"\u2193 {NetworkMonitor.FormatSpeed(_netMonitor.DownloadSpeed)}";
    }

    // ── Slide Animation ──
    private void SlideIn()
    {
        if (!_isHidden) return;
        _isHidden = false;
        var anim = new DoubleAnimation(_screenRight - Width - 4, TimeSpan.FromMilliseconds(200))
        {
            EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
        };
        BeginAnimation(LeftProperty, anim);
    }

    private void SlideToEdge()
    {
        if (_isHidden || _panel != null) return;
        _isHidden = true;
        NetSpeedPanel.Visibility = Visibility.Collapsed;
        var anim = new DoubleAnimation(_screenRight - PeekWidth, TimeSpan.FromMilliseconds(300))
        {
            EasingFunction = new CubicEase { EasingMode = EasingMode.EaseIn }
        };
        BeginAnimation(LeftProperty, anim);
    }

    // ── Drag ──
    private void OnBallMouseDown(object sender, MouseButtonEventArgs e)
    {
        _isDragging = false;
        _dragStart = e.GetPosition(this);
        _windowTop = Top;
        CaptureMouse();
    }

    private void OnBallMouseMove(object sender, MouseEventArgs e)
    {
        if (e.LeftButton != MouseButtonState.Pressed) return;
        var pos = e.GetPosition(this);
        if (Math.Abs(pos.Y - _dragStart.Y) > 5)
            _isDragging = true;
        if (_isDragging)
        {
            BeginAnimation(TopProperty, null);
            Top = _windowTop + (pos.Y - _dragStart.Y);
        }
    }

    private void OnBallMouseUp(object sender, MouseButtonEventArgs e)
    {
        ReleaseMouseCapture();
        if (!_isDragging)
        {
            OnBallClick();
        }
        else
        {
            _settings.BallPositionY = (int)Top;
            _settings.Save();
        }
        _isDragging = false;
    }

    // ── Click → Clean ──
    private async void OnBallClick()
    {
        if (_isCleaning) return;

        if (_panel != null)
        {
            ClosePanel();
            return;
        }

        await DoCleanAsync();
    }

    private async Task DoCleanAsync()
    {
        if (_isCleaning) return;
        _isCleaning = true;

        TxtPercent.Visibility = Visibility.Collapsed;
        TxtLabel.Visibility = Visibility.Collapsed;
        SpinnerOverlay.Visibility = Visibility.Visible;
        if (_spinStoryboard != null) _spinStoryboard.Begin();

        var result = await Task.Run(() => _memService.CleanMemory());
        var freed = result.freedBytes;

        if (_spinStoryboard != null) _spinStoryboard.Stop();
        SpinnerOverlay.Visibility = Visibility.Collapsed;
        TxtPercent.Visibility = Visibility.Visible;
        TxtLabel.Visibility = Visibility.Visible;
        _isCleaning = false;

        UpdateMemoryDisplay();
        ShowTooltip($"已释放 {ProcessInfo.FormatBytes(freed)}");
    }

    private void ShowTooltip(string text)
    {
        var tip = new ToolTipPopup(text);
        tip.Left = Left - tip.Width + 10;
        tip.Top = Top - 36;
        tip.Show();
    }

    // ── Right-click → Panel ──
    private void OnRightClick(object sender, MouseButtonEventArgs e)
    {
        if (_panel != null) { ClosePanel(); return; }
        OpenPanel();
    }

    private void OpenPanel()
    {
        _hideTimer.Stop();
        _panel = new BoosterPanel(_memService, _netMonitor, _settings);
        _panel.Left = Left - _panel.Width - 6;
        _panel.Top = Math.Max(10, Top - 150);
        _panel.Closed += (s2, e2) => { _panel = null; _hideTimer.Start(); };
        _panel.SettingsChanged += () => { ApplySettings(); };
        _panel.Show();
    }

    private void ClosePanel()
    {
        if (_panel != null) _panel.Close();
        _panel = null;
    }

    public void ApplySettings()
    {
        Opacity = _settings.BallOpacity;
        ApplyAutoCleanSettings();
        _settings.Save();
    }

    private void ApplyAutoCleanSettings()
    {
        if (_settings.AutoClean && _settings.AutoCleanIntervalMinutes > 0)
        {
            _autoCleanTimer.Interval = TimeSpan.FromMinutes(_settings.AutoCleanIntervalMinutes);
            _autoCleanTimer.Start();
        }
        else
        {
            _autoCleanTimer.Stop();
        }
    }
}