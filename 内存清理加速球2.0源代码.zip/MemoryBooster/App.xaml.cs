﻿using System;
using System.IO;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;

namespace MemoryBooster;

public partial class App : Application
{
    // Crash log lives next to the exe when writable, otherwise falls back to
    // %LocalAppData%\MemoryBooster\error.log so Program Files installs still
    // get a paper trail.
    private static string _logPath;

    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        ShutdownMode = ShutdownMode.OnMainWindowClose;

        _logPath = ResolveLogPath();

        DispatcherUnhandledException += OnDispatcherException;
        AppDomain.CurrentDomain.UnhandledException += OnDomainException;
        TaskScheduler.UnobservedTaskException += OnTaskException;
    }

    private static string ResolveLogPath()
    {
        try
        {
            var p = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "error.log");
            // Probe write access.
            using (File.Open(p, FileMode.Append, FileAccess.Write, FileShare.ReadWrite)) { }
            return p;
        }
        catch { }
        try
        {
            var dir = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "MemoryBooster");
            Directory.CreateDirectory(dir);
            return Path.Combine(dir, "error.log");
        }
        catch { return null; }
    }

    private void OnDispatcherException(object sender, DispatcherUnhandledExceptionEventArgs e)
    {
        // Non-fatal — log, show a toast-ish dialog, keep the app running.
        LogError(e.Exception, "Dispatcher");
        e.Handled = true;
        ShowErrorDialog(e.Exception, fatal: false);
    }

    private void OnDomainException(object sender, UnhandledExceptionEventArgs e)
    {
        if (e.ExceptionObject is Exception ex)
        {
            LogError(ex, "Domain-fatal");
            ShowErrorDialog(ex, fatal: true);
        }
    }

    private void OnTaskException(object sender, UnobservedTaskExceptionEventArgs e)
    {
        LogError(e.Exception, "UnobservedTask");
        e.SetObserved();
    }

    private static void LogError(Exception ex, string source)
    {
        if (_logPath == null) return;
        try
        {
            var sb = new StringBuilder();
            sb.Append('=', 72).AppendLine();
            sb.AppendLine($"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] source={source}");
            sb.AppendLine($"os   = {Environment.OSVersion} ({(Environment.Is64BitOperatingSystem ? "x64" : "x86")})");
            sb.AppendLine($"app  = {Assembly.GetExecutingAssembly().GetName().Version}");
            sb.AppendLine($"proc = {(Environment.Is64BitProcess ? "64-bit" : "32-bit")}");
            sb.AppendLine(ex.ToString());
            sb.AppendLine();
            File.AppendAllText(_logPath, sb.ToString());
        }
        catch { }
    }

    private static void ShowErrorDialog(Exception ex, bool fatal)
    {
        try
        {
            string header = fatal ? "程序发生严重错误即将退出" : "程序发生错误（已忽略）";
            string body = $"{header}\n\n{ex.GetType().Name}: {ex.Message}\n\n日志已写入：\n{_logPath ?? "(路径不可用)"}";
            MessageBox.Show(body, "Memory Booster",
                MessageBoxButton.OK,
                fatal ? MessageBoxImage.Error : MessageBoxImage.Warning);
        }
        catch { }
    }
}
